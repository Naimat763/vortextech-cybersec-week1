# Week 1 — Social Media Copy

Publish these after the report is uploaded to GitHub. Add your actual public repository link after confirming the files are visible.

## LinkedIn main post

🔐 **Cybersecurity Internship | Week 1 — OWASP Top 10:2025**

I’m building my cybersecurity foundations with **Vortex Tech Academy** and have prepared my Week 1 research report on five OWASP Top 10:2025 risks:

🔹 **A01 — Broken Access Control:** Ensuring users can access only what they are permitted to access.  
🔹 **A02 — Security Misconfiguration:** Preventing unsafe application, server, and cloud settings.  
🔹 **A03 — Software Supply Chain Failures:** Protecting dependencies, build systems, and software updates.  
🔹 **A04 — Cryptographic Failures:** Protecting sensitive data with strong, correctly implemented cryptography.  
🔹 **A07 — Authentication Failures:** Preventing unauthorized sign-ins through stronger identity and account controls.

For each topic, I documented what it means, a high-level attack scenario, a real-world case, and practical prevention measures—with references to trusted sources.

I’m continuing to learn through authorized hands-on labs and documenting my progress on GitHub.

🤝 I’d love to connect with cybersecurity professionals, SOC analysts, application security practitioners, and HR/recruitment professionals.

💬 Comment **“OWASP”** to exchange learning notes. Let’s connect and keep learning!

GitHub Portfolio: [PASTE YOUR PUBLIC REPOSITORY LINK]

#CyberSecurity #OWASPTop10 #ApplicationSecurity #CyberSecurityInternship #VortexTechAcademy

## LinkedIn Featured

**Title:** Week 1 Cybersecurity Research — OWASP Top 10:2025 (5 Risks)

**Description:** A research report created as part of my cybersecurity learning journey with Vortex Tech Academy. Covers Broken Access Control, Security Misconfiguration, Software Supply Chain Failures, Cryptographic Failures, and Authentication Failures. Each section includes a plain-language explanation, high-level attacker scenario, documented case study, developer mitigations, and references.

## GitHub repository description

Week 1 Vortex Tech Academy cybersecurity research: five OWASP Top 10:2025 risks, real-world case studies, and practical prevention guidance.

## Facebook post

🔐 **My Cybersecurity Learning Journey | Week 1 — OWASP Top 10:2025**

As part of my cybersecurity journey with **Vortex Tech Academy**, I prepared a research report covering five important web application security risks:

✅ Broken Access Control — checking permissions correctly.  
✅ Security Misconfiguration — keeping application and cloud settings secure.  
✅ Software Supply Chain Failures — protecting software components and updates.  
✅ Cryptographic Failures — protecting sensitive information with strong cryptography.  
✅ Authentication Failures — preventing unauthorized account access.

I included simple explanations, real-world case studies, prevention tips, and trusted references.

I’m continuing to improve through authorized labs, research, and documentation. I’d be glad to connect with cybersecurity learners and professionals, SOC analysts, and recruiters.

💬 Comment **“OWASP”** if you’d like to discuss the topics. Let’s learn and grow together!

GitHub: [PASTE YOUR PUBLIC REPOSITORY LINK]

#CyberSecurity #OWASPTop10 #VortexTechAcademy
